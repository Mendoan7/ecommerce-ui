export const STATUS_ORDER = {
  pending_payment: "Belum Bayar",
  paid: "Sudah Dibayar",
  on_processing: "Sedang Dikemas",
  on_delivery: "Dikirim",
  done: "Selesai",
  failed: "Dibatalkan",
};

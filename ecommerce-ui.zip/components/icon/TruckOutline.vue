<template>
  <svg
    width="31"
    height="30"
    viewBox="0 0 31 30"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M17.4688 19.2188H9.5"
      stroke="currentColor"
      stroke-width="2.8125"
      stroke-miterlimit="10"
      stroke-linejoin="round"
    />
    <path
      d="M7.53125 25.7812C9.60232 25.7812 11.2812 24.1023 11.2812 22.0312C11.2812 19.9602 9.60232 18.2812 7.53125 18.2812C5.46018 18.2812 3.78125 19.9602 3.78125 22.0312C3.78125 24.1023 5.46018 25.7812 7.53125 25.7812Z"
      stroke="currentColor"
      stroke-width="2.8125"
      stroke-miterlimit="10"
    />
    <path
      d="M19.7188 25.7812C21.7898 25.7812 23.4688 24.1023 23.4688 22.0312C23.4688 19.9602 21.7898 18.2812 19.7188 18.2812C17.6477 18.2812 15.9688 19.9602 15.9688 22.0312C15.9688 24.1023 17.6477 25.7812 19.7188 25.7812Z"
      stroke="currentColor"
      stroke-width="2.8125"
      stroke-miterlimit="10"
    />
    <path
      d="M18.9688 14.5312H28.625"
      stroke="currentColor"
      stroke-width="2.8125"
      stroke-miterlimit="10"
    />
    <path
      d="M4.8125 19.2188H1.90625V4.21875H19.7188V17.25"
      stroke="currentColor"
      stroke-width="2.8125"
      stroke-miterlimit="10"
      stroke-linejoin="round"
    />
    <path
      d="M19.7188 8.4375H28.1562L29.0938 20.625H23.6563"
      stroke="currentColor"
      stroke-width="2.8125"
      stroke-miterlimit="10"
      stroke-linejoin="round"
    />
  </svg>
</template>

<script setup></script>

<style scoped></style>
\

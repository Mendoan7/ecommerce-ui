<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="12"
    height="12"
    viewBox="0 0 12 12"
    fill="none"
  >
    <path
      d="M4.39922 10.5668V4.6468L1.19922 0.966797H10.7992L7.59922 4.6468V8.1668"
      stroke="black"
      stroke-opacity="0.8"
      stroke-width="0.8"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>

<script setup></script>

<style scoped></style>

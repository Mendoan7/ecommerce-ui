<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="87"
    height="8"
    viewBox="0 0 87 8"
    fill="none"
  >
    <rect
      width="85"
      height="1"
      transform="translate(0.660156 3.19922)"
      fill="black"
      fill-opacity="0.26"
    />
    <mask id="path-1-inside-1_30_6097" fill="white">
      <path
        d="M83.1602 0.160156L86.6957 3.69569L83.1602 7.23123L79.6246 3.69569L83.1602 0.160156Z"
      />
    </mask>
    <path
      d="M86.6957 3.69569L87.4028 4.4028L88.1099 3.69569L87.4028 2.98859L86.6957 3.69569ZM82.453 0.867263L85.9886 4.4028L87.4028 2.98859L83.8673 -0.546951L82.453 0.867263ZM85.9886 2.98859L82.453 6.52413L83.8673 7.93834L87.4028 4.4028L85.9886 2.98859Z"
      fill="black"
      fill-opacity="0.26"
      mask="url(#path-1-inside-1_30_6097)"
    />
  </svg>
</template>

<script setup></script>

<style scoped></style>

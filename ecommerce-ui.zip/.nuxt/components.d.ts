
import type { DefineComponent, SlotsType } from 'vue'
type IslandComponent<T extends DefineComponent> = T & DefineComponent<{}, {refresh: () => Promise<void>}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, SlotsType<{ fallback: { error: unknown } }>>
type HydrationStrategies = {
  hydrateOnVisible?: IntersectionObserverInit | true
  hydrateOnIdle?: number | true
  hydrateOnInteraction?: keyof HTMLElementEventMap | Array<keyof HTMLElementEventMap> | true
  hydrateOnMediaQuery?: string
  hydrateAfter?: number
  hydrateWhen?: boolean
  hydrateNever?: true
}
type LazyComponent<T> = (T & DefineComponent<HydrationStrategies, {}, {}, {}, {}, {}, {}, { hydrated: () => void }>)
interface _GlobalComponents {
      'BaseButtonGoogleSignIn': typeof import("../components/base/ButtonGoogleSignIn.vue")['default']
    'BaseCarousel': typeof import("../components/base/Carousel.vue")['default']
    'BaseDataTable': typeof import("../components/base/DataTable.vue")['default']
    'BaseDatePicker': typeof import("../components/base/DatePicker.vue")['default']
    'BaseInputPassword': typeof import("../components/base/InputPassword.vue")['default']
    'BaseInputPin': typeof import("../components/base/InputPin.vue")['default']
    'BaseInputQuantity': typeof import("../components/base/InputQuantity.vue")['default']
    'BaseLoading': typeof import("../components/base/Loading.vue")['default']
    'BaseLogo': typeof import("../components/base/Logo.vue")['default']
    'BasePagination': typeof import("../components/base/Pagination.vue")['default']
    'BaseProductCard': typeof import("../components/base/ProductCard.vue")['default']
    'BaseRadioCard': typeof import("../components/base/RadioCard.vue")['default']
    'BaseRating': typeof import("../components/base/Rating.vue")['default']
    'BaseTabs': typeof import("../components/base/Tabs.vue")['default']
    'BaseTimelineHorizontalItem': typeof import("../components/base/TimelineHorizontal/Item.vue")['default']
    'BaseTimelineHorizontal': typeof import("../components/base/TimelineHorizontal/index.vue")['default']
    'BaseTimelineVerticalItem': typeof import("../components/base/TimelineVertical/Item.vue")['default']
    'BaseTimelineVertical': typeof import("../components/base/TimelineVertical/index.vue")['default']
    'FeatureCartProductItem': typeof import("../components/feature/Cart/ProductItem.vue")['default']
    'FeatureForgotPasswordEmail': typeof import("../components/feature/ForgotPassword/Email.vue")['default']
    'FeatureHomepageCarousel': typeof import("../components/feature/Homepage/Carousel.vue")['default']
    'FeatureHomepageCategoryItem': typeof import("../components/feature/Homepage/CategoryItem.vue")['default']
    'FeatureProductDetailCarousel': typeof import("../components/feature/ProductDetail/Carousel.vue")['default']
    'FeatureProductDetailReview': typeof import("../components/feature/ProductDetail/Review.vue")['default']
    'FeatureProfileAddressCardItem': typeof import("../components/feature/ProfileAddress/CardItem.vue")['default']
    'FeatureProfileAddressInputSelectCity': typeof import("../components/feature/ProfileAddress/InputSelectCity.vue")['default']
    'FeatureProfileAddressModalMutation': typeof import("../components/feature/ProfileAddress/ModalMutation.vue")['default']
    'FeatureProfileOrderCardOrder': typeof import("../components/feature/ProfileOrder/CardOrder.vue")['default']
    'FeatureProfileOrderCardProduct': typeof import("../components/feature/ProfileOrder/CardProduct.vue")['default']
    'FeatureSellerProductMedia': typeof import("../components/feature/Seller/Product/Media.vue")['default']
    'FeatureSellerProductVariant': typeof import("../components/feature/Seller/Product/Variant.vue")['default']
    'FormCompleted': typeof import("../components/form/Completed.vue")['default']
    'FormOtp': typeof import("../components/form/Otp.vue")['default']
    'FormPassword': typeof import("../components/form/Password.vue")['default']
    'IconCart': typeof import("../components/icon/Cart.vue")['default']
    'IconCartPlus': typeof import("../components/icon/CartPlus.vue")['default']
    'IconCoin': typeof import("../components/icon/Coin.vue")['default']
    'IconCoinSolid': typeof import("../components/icon/CoinSolid.vue")['default']
    'IconEmpty': typeof import("../components/icon/Empty.vue")['default']
    'IconFilter': typeof import("../components/icon/Filter.vue")['default']
    'IconInbox': typeof import("../components/icon/Inbox.vue")['default']
    'IconLamp': typeof import("../components/icon/Lamp.vue")['default']
    'IconLoading': typeof import("../components/icon/Loading.vue")['default']
    'IconOrder': typeof import("../components/icon/Order.vue")['default']
    'IconPaid': typeof import("../components/icon/Paid.vue")['default']
    'IconShop': typeof import("../components/icon/Shop.vue")['default']
    'IconStars': typeof import("../components/icon/Stars.vue")['default']
    'IconStepArrow': typeof import("../components/icon/StepArrow.vue")['default']
    'IconTruck': typeof import("../components/icon/Truck.vue")['default']
    'IconTruckOutline': typeof import("../components/icon/TruckOutline.vue")['default']
    'IconUserCheck': typeof import("../components/icon/UserCheck.vue")['default']
    'IconVoucher': typeof import("../components/icon/Voucher.vue")['default']
    'LayoutsFooter': typeof import("../components/layouts/Footer.vue")['default']
    'LayoutsHeaderAuth': typeof import("../components/layouts/HeaderAuth.vue")['default']
    'LayoutsHeaderProfile': typeof import("../components/layouts/HeaderProfile.vue")['default']
    'LayoutsHeaderSeller': typeof import("../components/layouts/HeaderSeller.vue")['default']
    'LayoutsHeaderWhite': typeof import("../components/layouts/HeaderWhite.vue")['default']
    'LayoutsSearchBar': typeof import("../components/layouts/SearchBar.vue")['default']
    'LayoutsSidebar': typeof import("../components/layouts/sidebar/Index.vue")['default']
    'LayoutsSidebarItem': typeof import("../components/layouts/sidebar/Item.vue")['default']
    'ModalAddress': typeof import("../components/modal/Address.vue")['default']
    'ModalCourier': typeof import("../components/modal/Courier.vue")['default']
    'ModalReview': typeof import("../components/modal/Review.vue")['default']
    'ModalReviewItem': typeof import("../components/modal/Review/Item.vue")['default']
    'ModalVoucher': typeof import("../components/modal/Voucher.vue")['default']
    'MyAccountFormGroup': typeof import("../components/my-account/FormGroup.vue")['default']
    'SellerCard': typeof import("../components/seller/Card.vue")['default']
    'SellerFormGroup': typeof import("../components/seller/FormGroup.vue")['default']
    'UAccordion': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Accordion.vue")['default']
    'UAlert': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Alert.vue")['default']
    'UAvatar': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Avatar.vue")['default']
    'UAvatarGroup': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/AvatarGroup")['default']
    'UBadge': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Badge.vue")['default']
    'UButton': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Button.vue")['default']
    'UButtonGroup': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/ButtonGroup")['default']
    'UCarousel': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Carousel.vue")['default']
    'UChip': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Chip.vue")['default']
    'UDropdown': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Dropdown.vue")['default']
    'UIcon': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Icon.vue")['default']
    'UKbd': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Kbd.vue")['default']
    'ULink': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Link.vue")['default']
    'UMeter': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Meter.vue")['default']
    'UMeterGroup': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/MeterGroup")['default']
    'UProgress': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Progress.vue")['default']
    'UCheckbox': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Checkbox.vue")['default']
    'UForm': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Form.vue")['default']
    'UFormGroup': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/FormGroup.vue")['default']
    'UInput': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Input.vue")['default']
    'UInputMenu': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/InputMenu.vue")['default']
    'URadio': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Radio.vue")['default']
    'URadioGroup': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/RadioGroup.vue")['default']
    'URange': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Range.vue")['default']
    'USelect': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Select.vue")['default']
    'USelectMenu': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/SelectMenu.vue")['default']
    'UTextarea': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Textarea.vue")['default']
    'UToggle': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Toggle.vue")['default']
    'UTable': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/data/Table.vue")['default']
    'UCard': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/layout/Card.vue")['default']
    'UContainer': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/layout/Container.vue")['default']
    'UDivider': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/layout/Divider.vue")['default']
    'USkeleton': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/layout/Skeleton.vue")['default']
    'UBreadcrumb': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/Breadcrumb.vue")['default']
    'UCommandPalette': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/CommandPalette.vue")['default']
    'UCommandPaletteGroup': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/CommandPaletteGroup.vue")['default']
    'UHorizontalNavigation': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/HorizontalNavigation.vue")['default']
    'UPagination': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/Pagination.vue")['default']
    'UTabs': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/Tabs.vue")['default']
    'UVerticalNavigation': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/VerticalNavigation.vue")['default']
    'UContextMenu': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/ContextMenu.vue")['default']
    'UModal': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Modal.vue")['default']
    'UModals': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Modals.client.vue")['default']
    'UNotification': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Notification.vue")['default']
    'UNotifications': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Notifications.vue")['default']
    'UPopover': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Popover.vue")['default']
    'USlideover': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Slideover.vue")['default']
    'USlideovers': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Slideovers.client.vue")['default']
    'UTooltip': typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Tooltip.vue")['default']
    'NuxtWelcome': typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']
    'NuxtLayout': typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']
    'NuxtErrorBoundary': typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']
    'ClientOnly': typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']
    'DevOnly': typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']
    'ServerPlaceholder': typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']
    'NuxtLink': typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']
    'NuxtLoadingIndicator': typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']
    'NuxtTime': typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']
    'NuxtRouteAnnouncer': typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']
    'NuxtImg': typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue")['default']
    'NuxtPicture': typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtPicture.vue")['default']
    'Icon': typeof import("../node_modules/@nuxt/icon/dist/runtime/components/index")['default']
    'ColorScheme': typeof import("../node_modules/@nuxtjs/color-mode/dist/runtime/component.vue3.vue")['default']
    'NuxtPage': typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']
    'NoScript': typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']
    'Link': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']
    'Base': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']
    'Title': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']
    'Meta': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']
    'Style': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']
    'Head': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']
    'Html': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']
    'Body': typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']
    'NuxtIsland': typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']
    'UModals': IslandComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
    'USlideovers': IslandComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
    'NuxtRouteAnnouncer': IslandComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
      'LazyBaseButtonGoogleSignIn': LazyComponent<typeof import("../components/base/ButtonGoogleSignIn.vue")['default']>
    'LazyBaseCarousel': LazyComponent<typeof import("../components/base/Carousel.vue")['default']>
    'LazyBaseDataTable': LazyComponent<typeof import("../components/base/DataTable.vue")['default']>
    'LazyBaseDatePicker': LazyComponent<typeof import("../components/base/DatePicker.vue")['default']>
    'LazyBaseInputPassword': LazyComponent<typeof import("../components/base/InputPassword.vue")['default']>
    'LazyBaseInputPin': LazyComponent<typeof import("../components/base/InputPin.vue")['default']>
    'LazyBaseInputQuantity': LazyComponent<typeof import("../components/base/InputQuantity.vue")['default']>
    'LazyBaseLoading': LazyComponent<typeof import("../components/base/Loading.vue")['default']>
    'LazyBaseLogo': LazyComponent<typeof import("../components/base/Logo.vue")['default']>
    'LazyBasePagination': LazyComponent<typeof import("../components/base/Pagination.vue")['default']>
    'LazyBaseProductCard': LazyComponent<typeof import("../components/base/ProductCard.vue")['default']>
    'LazyBaseRadioCard': LazyComponent<typeof import("../components/base/RadioCard.vue")['default']>
    'LazyBaseRating': LazyComponent<typeof import("../components/base/Rating.vue")['default']>
    'LazyBaseTabs': LazyComponent<typeof import("../components/base/Tabs.vue")['default']>
    'LazyBaseTimelineHorizontalItem': LazyComponent<typeof import("../components/base/TimelineHorizontal/Item.vue")['default']>
    'LazyBaseTimelineHorizontal': LazyComponent<typeof import("../components/base/TimelineHorizontal/index.vue")['default']>
    'LazyBaseTimelineVerticalItem': LazyComponent<typeof import("../components/base/TimelineVertical/Item.vue")['default']>
    'LazyBaseTimelineVertical': LazyComponent<typeof import("../components/base/TimelineVertical/index.vue")['default']>
    'LazyFeatureCartProductItem': LazyComponent<typeof import("../components/feature/Cart/ProductItem.vue")['default']>
    'LazyFeatureForgotPasswordEmail': LazyComponent<typeof import("../components/feature/ForgotPassword/Email.vue")['default']>
    'LazyFeatureHomepageCarousel': LazyComponent<typeof import("../components/feature/Homepage/Carousel.vue")['default']>
    'LazyFeatureHomepageCategoryItem': LazyComponent<typeof import("../components/feature/Homepage/CategoryItem.vue")['default']>
    'LazyFeatureProductDetailCarousel': LazyComponent<typeof import("../components/feature/ProductDetail/Carousel.vue")['default']>
    'LazyFeatureProductDetailReview': LazyComponent<typeof import("../components/feature/ProductDetail/Review.vue")['default']>
    'LazyFeatureProfileAddressCardItem': LazyComponent<typeof import("../components/feature/ProfileAddress/CardItem.vue")['default']>
    'LazyFeatureProfileAddressInputSelectCity': LazyComponent<typeof import("../components/feature/ProfileAddress/InputSelectCity.vue")['default']>
    'LazyFeatureProfileAddressModalMutation': LazyComponent<typeof import("../components/feature/ProfileAddress/ModalMutation.vue")['default']>
    'LazyFeatureProfileOrderCardOrder': LazyComponent<typeof import("../components/feature/ProfileOrder/CardOrder.vue")['default']>
    'LazyFeatureProfileOrderCardProduct': LazyComponent<typeof import("../components/feature/ProfileOrder/CardProduct.vue")['default']>
    'LazyFeatureSellerProductMedia': LazyComponent<typeof import("../components/feature/Seller/Product/Media.vue")['default']>
    'LazyFeatureSellerProductVariant': LazyComponent<typeof import("../components/feature/Seller/Product/Variant.vue")['default']>
    'LazyFormCompleted': LazyComponent<typeof import("../components/form/Completed.vue")['default']>
    'LazyFormOtp': LazyComponent<typeof import("../components/form/Otp.vue")['default']>
    'LazyFormPassword': LazyComponent<typeof import("../components/form/Password.vue")['default']>
    'LazyIconCart': LazyComponent<typeof import("../components/icon/Cart.vue")['default']>
    'LazyIconCartPlus': LazyComponent<typeof import("../components/icon/CartPlus.vue")['default']>
    'LazyIconCoin': LazyComponent<typeof import("../components/icon/Coin.vue")['default']>
    'LazyIconCoinSolid': LazyComponent<typeof import("../components/icon/CoinSolid.vue")['default']>
    'LazyIconEmpty': LazyComponent<typeof import("../components/icon/Empty.vue")['default']>
    'LazyIconFilter': LazyComponent<typeof import("../components/icon/Filter.vue")['default']>
    'LazyIconInbox': LazyComponent<typeof import("../components/icon/Inbox.vue")['default']>
    'LazyIconLamp': LazyComponent<typeof import("../components/icon/Lamp.vue")['default']>
    'LazyIconLoading': LazyComponent<typeof import("../components/icon/Loading.vue")['default']>
    'LazyIconOrder': LazyComponent<typeof import("../components/icon/Order.vue")['default']>
    'LazyIconPaid': LazyComponent<typeof import("../components/icon/Paid.vue")['default']>
    'LazyIconShop': LazyComponent<typeof import("../components/icon/Shop.vue")['default']>
    'LazyIconStars': LazyComponent<typeof import("../components/icon/Stars.vue")['default']>
    'LazyIconStepArrow': LazyComponent<typeof import("../components/icon/StepArrow.vue")['default']>
    'LazyIconTruck': LazyComponent<typeof import("../components/icon/Truck.vue")['default']>
    'LazyIconTruckOutline': LazyComponent<typeof import("../components/icon/TruckOutline.vue")['default']>
    'LazyIconUserCheck': LazyComponent<typeof import("../components/icon/UserCheck.vue")['default']>
    'LazyIconVoucher': LazyComponent<typeof import("../components/icon/Voucher.vue")['default']>
    'LazyLayoutsFooter': LazyComponent<typeof import("../components/layouts/Footer.vue")['default']>
    'LazyLayoutsHeaderAuth': LazyComponent<typeof import("../components/layouts/HeaderAuth.vue")['default']>
    'LazyLayoutsHeaderProfile': LazyComponent<typeof import("../components/layouts/HeaderProfile.vue")['default']>
    'LazyLayoutsHeaderSeller': LazyComponent<typeof import("../components/layouts/HeaderSeller.vue")['default']>
    'LazyLayoutsHeaderWhite': LazyComponent<typeof import("../components/layouts/HeaderWhite.vue")['default']>
    'LazyLayoutsSearchBar': LazyComponent<typeof import("../components/layouts/SearchBar.vue")['default']>
    'LazyLayoutsSidebar': LazyComponent<typeof import("../components/layouts/sidebar/Index.vue")['default']>
    'LazyLayoutsSidebarItem': LazyComponent<typeof import("../components/layouts/sidebar/Item.vue")['default']>
    'LazyModalAddress': LazyComponent<typeof import("../components/modal/Address.vue")['default']>
    'LazyModalCourier': LazyComponent<typeof import("../components/modal/Courier.vue")['default']>
    'LazyModalReview': LazyComponent<typeof import("../components/modal/Review.vue")['default']>
    'LazyModalReviewItem': LazyComponent<typeof import("../components/modal/Review/Item.vue")['default']>
    'LazyModalVoucher': LazyComponent<typeof import("../components/modal/Voucher.vue")['default']>
    'LazyMyAccountFormGroup': LazyComponent<typeof import("../components/my-account/FormGroup.vue")['default']>
    'LazySellerCard': LazyComponent<typeof import("../components/seller/Card.vue")['default']>
    'LazySellerFormGroup': LazyComponent<typeof import("../components/seller/FormGroup.vue")['default']>
    'LazyUAccordion': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Accordion.vue")['default']>
    'LazyUAlert': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Alert.vue")['default']>
    'LazyUAvatar': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Avatar.vue")['default']>
    'LazyUAvatarGroup': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/AvatarGroup")['default']>
    'LazyUBadge': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Badge.vue")['default']>
    'LazyUButton': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Button.vue")['default']>
    'LazyUButtonGroup': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/ButtonGroup")['default']>
    'LazyUCarousel': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Carousel.vue")['default']>
    'LazyUChip': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Chip.vue")['default']>
    'LazyUDropdown': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Dropdown.vue")['default']>
    'LazyUIcon': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Icon.vue")['default']>
    'LazyUKbd': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Kbd.vue")['default']>
    'LazyULink': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Link.vue")['default']>
    'LazyUMeter': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Meter.vue")['default']>
    'LazyUMeterGroup': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/MeterGroup")['default']>
    'LazyUProgress': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Progress.vue")['default']>
    'LazyUCheckbox': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Checkbox.vue")['default']>
    'LazyUForm': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Form.vue")['default']>
    'LazyUFormGroup': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/FormGroup.vue")['default']>
    'LazyUInput': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Input.vue")['default']>
    'LazyUInputMenu': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/InputMenu.vue")['default']>
    'LazyURadio': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Radio.vue")['default']>
    'LazyURadioGroup': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/RadioGroup.vue")['default']>
    'LazyURange': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Range.vue")['default']>
    'LazyUSelect': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Select.vue")['default']>
    'LazyUSelectMenu': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/SelectMenu.vue")['default']>
    'LazyUTextarea': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Textarea.vue")['default']>
    'LazyUToggle': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Toggle.vue")['default']>
    'LazyUTable': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/data/Table.vue")['default']>
    'LazyUCard': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/layout/Card.vue")['default']>
    'LazyUContainer': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/layout/Container.vue")['default']>
    'LazyUDivider': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/layout/Divider.vue")['default']>
    'LazyUSkeleton': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/layout/Skeleton.vue")['default']>
    'LazyUBreadcrumb': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/Breadcrumb.vue")['default']>
    'LazyUCommandPalette': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/CommandPalette.vue")['default']>
    'LazyUCommandPaletteGroup': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/CommandPaletteGroup.vue")['default']>
    'LazyUHorizontalNavigation': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/HorizontalNavigation.vue")['default']>
    'LazyUPagination': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/Pagination.vue")['default']>
    'LazyUTabs': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/Tabs.vue")['default']>
    'LazyUVerticalNavigation': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/VerticalNavigation.vue")['default']>
    'LazyUContextMenu': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/ContextMenu.vue")['default']>
    'LazyUModal': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Modal.vue")['default']>
    'LazyUModals': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Modals.client.vue")['default']>
    'LazyUNotification': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Notification.vue")['default']>
    'LazyUNotifications': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Notifications.vue")['default']>
    'LazyUPopover': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Popover.vue")['default']>
    'LazyUSlideover': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Slideover.vue")['default']>
    'LazyUSlideovers': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Slideovers.client.vue")['default']>
    'LazyUTooltip': LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Tooltip.vue")['default']>
    'LazyNuxtWelcome': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']>
    'LazyNuxtLayout': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']>
    'LazyNuxtErrorBoundary': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']>
    'LazyClientOnly': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']>
    'LazyDevOnly': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']>
    'LazyServerPlaceholder': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
    'LazyNuxtLink': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']>
    'LazyNuxtLoadingIndicator': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']>
    'LazyNuxtTime': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']>
    'LazyNuxtRouteAnnouncer': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']>
    'LazyNuxtImg': LazyComponent<typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue")['default']>
    'LazyNuxtPicture': LazyComponent<typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtPicture.vue")['default']>
    'LazyIcon': LazyComponent<typeof import("../node_modules/@nuxt/icon/dist/runtime/components/index")['default']>
    'LazyColorScheme': LazyComponent<typeof import("../node_modules/@nuxtjs/color-mode/dist/runtime/component.vue3.vue")['default']>
    'LazyNuxtPage': LazyComponent<typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']>
    'LazyNoScript': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']>
    'LazyLink': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']>
    'LazyBase': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']>
    'LazyTitle': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']>
    'LazyMeta': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']>
    'LazyStyle': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']>
    'LazyHead': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']>
    'LazyHtml': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']>
    'LazyBody': LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']>
    'LazyNuxtIsland': LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']>
    'LazyUModals': LazyComponent<IslandComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>>
    'LazyUSlideovers': LazyComponent<IslandComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>>
    'LazyNuxtRouteAnnouncer': LazyComponent<IslandComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>>
}

declare module 'vue' {
  export interface GlobalComponents extends _GlobalComponents { }
}

export const BaseButtonGoogleSignIn: typeof import("../components/base/ButtonGoogleSignIn.vue")['default']
export const BaseCarousel: typeof import("../components/base/Carousel.vue")['default']
export const BaseDataTable: typeof import("../components/base/DataTable.vue")['default']
export const BaseDatePicker: typeof import("../components/base/DatePicker.vue")['default']
export const BaseInputPassword: typeof import("../components/base/InputPassword.vue")['default']
export const BaseInputPin: typeof import("../components/base/InputPin.vue")['default']
export const BaseInputQuantity: typeof import("../components/base/InputQuantity.vue")['default']
export const BaseLoading: typeof import("../components/base/Loading.vue")['default']
export const BaseLogo: typeof import("../components/base/Logo.vue")['default']
export const BasePagination: typeof import("../components/base/Pagination.vue")['default']
export const BaseProductCard: typeof import("../components/base/ProductCard.vue")['default']
export const BaseRadioCard: typeof import("../components/base/RadioCard.vue")['default']
export const BaseRating: typeof import("../components/base/Rating.vue")['default']
export const BaseTabs: typeof import("../components/base/Tabs.vue")['default']
export const BaseTimelineHorizontalItem: typeof import("../components/base/TimelineHorizontal/Item.vue")['default']
export const BaseTimelineHorizontal: typeof import("../components/base/TimelineHorizontal/index.vue")['default']
export const BaseTimelineVerticalItem: typeof import("../components/base/TimelineVertical/Item.vue")['default']
export const BaseTimelineVertical: typeof import("../components/base/TimelineVertical/index.vue")['default']
export const FeatureCartProductItem: typeof import("../components/feature/Cart/ProductItem.vue")['default']
export const FeatureForgotPasswordEmail: typeof import("../components/feature/ForgotPassword/Email.vue")['default']
export const FeatureHomepageCarousel: typeof import("../components/feature/Homepage/Carousel.vue")['default']
export const FeatureHomepageCategoryItem: typeof import("../components/feature/Homepage/CategoryItem.vue")['default']
export const FeatureProductDetailCarousel: typeof import("../components/feature/ProductDetail/Carousel.vue")['default']
export const FeatureProductDetailReview: typeof import("../components/feature/ProductDetail/Review.vue")['default']
export const FeatureProfileAddressCardItem: typeof import("../components/feature/ProfileAddress/CardItem.vue")['default']
export const FeatureProfileAddressInputSelectCity: typeof import("../components/feature/ProfileAddress/InputSelectCity.vue")['default']
export const FeatureProfileAddressModalMutation: typeof import("../components/feature/ProfileAddress/ModalMutation.vue")['default']
export const FeatureProfileOrderCardOrder: typeof import("../components/feature/ProfileOrder/CardOrder.vue")['default']
export const FeatureProfileOrderCardProduct: typeof import("../components/feature/ProfileOrder/CardProduct.vue")['default']
export const FeatureSellerProductMedia: typeof import("../components/feature/Seller/Product/Media.vue")['default']
export const FeatureSellerProductVariant: typeof import("../components/feature/Seller/Product/Variant.vue")['default']
export const FormCompleted: typeof import("../components/form/Completed.vue")['default']
export const FormOtp: typeof import("../components/form/Otp.vue")['default']
export const FormPassword: typeof import("../components/form/Password.vue")['default']
export const IconCart: typeof import("../components/icon/Cart.vue")['default']
export const IconCartPlus: typeof import("../components/icon/CartPlus.vue")['default']
export const IconCoin: typeof import("../components/icon/Coin.vue")['default']
export const IconCoinSolid: typeof import("../components/icon/CoinSolid.vue")['default']
export const IconEmpty: typeof import("../components/icon/Empty.vue")['default']
export const IconFilter: typeof import("../components/icon/Filter.vue")['default']
export const IconInbox: typeof import("../components/icon/Inbox.vue")['default']
export const IconLamp: typeof import("../components/icon/Lamp.vue")['default']
export const IconLoading: typeof import("../components/icon/Loading.vue")['default']
export const IconOrder: typeof import("../components/icon/Order.vue")['default']
export const IconPaid: typeof import("../components/icon/Paid.vue")['default']
export const IconShop: typeof import("../components/icon/Shop.vue")['default']
export const IconStars: typeof import("../components/icon/Stars.vue")['default']
export const IconStepArrow: typeof import("../components/icon/StepArrow.vue")['default']
export const IconTruck: typeof import("../components/icon/Truck.vue")['default']
export const IconTruckOutline: typeof import("../components/icon/TruckOutline.vue")['default']
export const IconUserCheck: typeof import("../components/icon/UserCheck.vue")['default']
export const IconVoucher: typeof import("../components/icon/Voucher.vue")['default']
export const LayoutsFooter: typeof import("../components/layouts/Footer.vue")['default']
export const LayoutsHeaderAuth: typeof import("../components/layouts/HeaderAuth.vue")['default']
export const LayoutsHeaderProfile: typeof import("../components/layouts/HeaderProfile.vue")['default']
export const LayoutsHeaderSeller: typeof import("../components/layouts/HeaderSeller.vue")['default']
export const LayoutsHeaderWhite: typeof import("../components/layouts/HeaderWhite.vue")['default']
export const LayoutsSearchBar: typeof import("../components/layouts/SearchBar.vue")['default']
export const LayoutsSidebar: typeof import("../components/layouts/sidebar/Index.vue")['default']
export const LayoutsSidebarItem: typeof import("../components/layouts/sidebar/Item.vue")['default']
export const ModalAddress: typeof import("../components/modal/Address.vue")['default']
export const ModalCourier: typeof import("../components/modal/Courier.vue")['default']
export const ModalReview: typeof import("../components/modal/Review.vue")['default']
export const ModalReviewItem: typeof import("../components/modal/Review/Item.vue")['default']
export const ModalVoucher: typeof import("../components/modal/Voucher.vue")['default']
export const MyAccountFormGroup: typeof import("../components/my-account/FormGroup.vue")['default']
export const SellerCard: typeof import("../components/seller/Card.vue")['default']
export const SellerFormGroup: typeof import("../components/seller/FormGroup.vue")['default']
export const UAccordion: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Accordion.vue")['default']
export const UAlert: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Alert.vue")['default']
export const UAvatar: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Avatar.vue")['default']
export const UAvatarGroup: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/AvatarGroup")['default']
export const UBadge: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Badge.vue")['default']
export const UButton: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Button.vue")['default']
export const UButtonGroup: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/ButtonGroup")['default']
export const UCarousel: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Carousel.vue")['default']
export const UChip: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Chip.vue")['default']
export const UDropdown: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Dropdown.vue")['default']
export const UIcon: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Icon.vue")['default']
export const UKbd: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Kbd.vue")['default']
export const ULink: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Link.vue")['default']
export const UMeter: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Meter.vue")['default']
export const UMeterGroup: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/MeterGroup")['default']
export const UProgress: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Progress.vue")['default']
export const UCheckbox: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Checkbox.vue")['default']
export const UForm: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Form.vue")['default']
export const UFormGroup: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/FormGroup.vue")['default']
export const UInput: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Input.vue")['default']
export const UInputMenu: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/InputMenu.vue")['default']
export const URadio: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Radio.vue")['default']
export const URadioGroup: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/RadioGroup.vue")['default']
export const URange: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Range.vue")['default']
export const USelect: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Select.vue")['default']
export const USelectMenu: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/SelectMenu.vue")['default']
export const UTextarea: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Textarea.vue")['default']
export const UToggle: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Toggle.vue")['default']
export const UTable: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/data/Table.vue")['default']
export const UCard: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/layout/Card.vue")['default']
export const UContainer: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/layout/Container.vue")['default']
export const UDivider: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/layout/Divider.vue")['default']
export const USkeleton: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/layout/Skeleton.vue")['default']
export const UBreadcrumb: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/Breadcrumb.vue")['default']
export const UCommandPalette: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/CommandPalette.vue")['default']
export const UCommandPaletteGroup: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/CommandPaletteGroup.vue")['default']
export const UHorizontalNavigation: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/HorizontalNavigation.vue")['default']
export const UPagination: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/Pagination.vue")['default']
export const UTabs: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/Tabs.vue")['default']
export const UVerticalNavigation: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/VerticalNavigation.vue")['default']
export const UContextMenu: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/ContextMenu.vue")['default']
export const UModal: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Modal.vue")['default']
export const UModals: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Modals.client.vue")['default']
export const UNotification: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Notification.vue")['default']
export const UNotifications: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Notifications.vue")['default']
export const UPopover: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Popover.vue")['default']
export const USlideover: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Slideover.vue")['default']
export const USlideovers: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Slideovers.client.vue")['default']
export const UTooltip: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Tooltip.vue")['default']
export const NuxtWelcome: typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']
export const NuxtLayout: typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']
export const NuxtErrorBoundary: typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']
export const ClientOnly: typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']
export const DevOnly: typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']
export const ServerPlaceholder: typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']
export const NuxtLink: typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']
export const NuxtLoadingIndicator: typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']
export const NuxtTime: typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']
export const NuxtRouteAnnouncer: typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']
export const NuxtImg: typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue")['default']
export const NuxtPicture: typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtPicture.vue")['default']
export const Icon: typeof import("../node_modules/@nuxt/icon/dist/runtime/components/index")['default']
export const ColorScheme: typeof import("../node_modules/@nuxtjs/color-mode/dist/runtime/component.vue3.vue")['default']
export const NuxtPage: typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']
export const NoScript: typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']
export const Link: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']
export const Base: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']
export const Title: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']
export const Meta: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']
export const Style: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']
export const Head: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']
export const Html: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']
export const Body: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']
export const NuxtIsland: typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']
export const UModals: IslandComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const USlideovers: IslandComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const NuxtRouteAnnouncer: IslandComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const LazyBaseButtonGoogleSignIn: LazyComponent<typeof import("../components/base/ButtonGoogleSignIn.vue")['default']>
export const LazyBaseCarousel: LazyComponent<typeof import("../components/base/Carousel.vue")['default']>
export const LazyBaseDataTable: LazyComponent<typeof import("../components/base/DataTable.vue")['default']>
export const LazyBaseDatePicker: LazyComponent<typeof import("../components/base/DatePicker.vue")['default']>
export const LazyBaseInputPassword: LazyComponent<typeof import("../components/base/InputPassword.vue")['default']>
export const LazyBaseInputPin: LazyComponent<typeof import("../components/base/InputPin.vue")['default']>
export const LazyBaseInputQuantity: LazyComponent<typeof import("../components/base/InputQuantity.vue")['default']>
export const LazyBaseLoading: LazyComponent<typeof import("../components/base/Loading.vue")['default']>
export const LazyBaseLogo: LazyComponent<typeof import("../components/base/Logo.vue")['default']>
export const LazyBasePagination: LazyComponent<typeof import("../components/base/Pagination.vue")['default']>
export const LazyBaseProductCard: LazyComponent<typeof import("../components/base/ProductCard.vue")['default']>
export const LazyBaseRadioCard: LazyComponent<typeof import("../components/base/RadioCard.vue")['default']>
export const LazyBaseRating: LazyComponent<typeof import("../components/base/Rating.vue")['default']>
export const LazyBaseTabs: LazyComponent<typeof import("../components/base/Tabs.vue")['default']>
export const LazyBaseTimelineHorizontalItem: LazyComponent<typeof import("../components/base/TimelineHorizontal/Item.vue")['default']>
export const LazyBaseTimelineHorizontal: LazyComponent<typeof import("../components/base/TimelineHorizontal/index.vue")['default']>
export const LazyBaseTimelineVerticalItem: LazyComponent<typeof import("../components/base/TimelineVertical/Item.vue")['default']>
export const LazyBaseTimelineVertical: LazyComponent<typeof import("../components/base/TimelineVertical/index.vue")['default']>
export const LazyFeatureCartProductItem: LazyComponent<typeof import("../components/feature/Cart/ProductItem.vue")['default']>
export const LazyFeatureForgotPasswordEmail: LazyComponent<typeof import("../components/feature/ForgotPassword/Email.vue")['default']>
export const LazyFeatureHomepageCarousel: LazyComponent<typeof import("../components/feature/Homepage/Carousel.vue")['default']>
export const LazyFeatureHomepageCategoryItem: LazyComponent<typeof import("../components/feature/Homepage/CategoryItem.vue")['default']>
export const LazyFeatureProductDetailCarousel: LazyComponent<typeof import("../components/feature/ProductDetail/Carousel.vue")['default']>
export const LazyFeatureProductDetailReview: LazyComponent<typeof import("../components/feature/ProductDetail/Review.vue")['default']>
export const LazyFeatureProfileAddressCardItem: LazyComponent<typeof import("../components/feature/ProfileAddress/CardItem.vue")['default']>
export const LazyFeatureProfileAddressInputSelectCity: LazyComponent<typeof import("../components/feature/ProfileAddress/InputSelectCity.vue")['default']>
export const LazyFeatureProfileAddressModalMutation: LazyComponent<typeof import("../components/feature/ProfileAddress/ModalMutation.vue")['default']>
export const LazyFeatureProfileOrderCardOrder: LazyComponent<typeof import("../components/feature/ProfileOrder/CardOrder.vue")['default']>
export const LazyFeatureProfileOrderCardProduct: LazyComponent<typeof import("../components/feature/ProfileOrder/CardProduct.vue")['default']>
export const LazyFeatureSellerProductMedia: LazyComponent<typeof import("../components/feature/Seller/Product/Media.vue")['default']>
export const LazyFeatureSellerProductVariant: LazyComponent<typeof import("../components/feature/Seller/Product/Variant.vue")['default']>
export const LazyFormCompleted: LazyComponent<typeof import("../components/form/Completed.vue")['default']>
export const LazyFormOtp: LazyComponent<typeof import("../components/form/Otp.vue")['default']>
export const LazyFormPassword: LazyComponent<typeof import("../components/form/Password.vue")['default']>
export const LazyIconCart: LazyComponent<typeof import("../components/icon/Cart.vue")['default']>
export const LazyIconCartPlus: LazyComponent<typeof import("../components/icon/CartPlus.vue")['default']>
export const LazyIconCoin: LazyComponent<typeof import("../components/icon/Coin.vue")['default']>
export const LazyIconCoinSolid: LazyComponent<typeof import("../components/icon/CoinSolid.vue")['default']>
export const LazyIconEmpty: LazyComponent<typeof import("../components/icon/Empty.vue")['default']>
export const LazyIconFilter: LazyComponent<typeof import("../components/icon/Filter.vue")['default']>
export const LazyIconInbox: LazyComponent<typeof import("../components/icon/Inbox.vue")['default']>
export const LazyIconLamp: LazyComponent<typeof import("../components/icon/Lamp.vue")['default']>
export const LazyIconLoading: LazyComponent<typeof import("../components/icon/Loading.vue")['default']>
export const LazyIconOrder: LazyComponent<typeof import("../components/icon/Order.vue")['default']>
export const LazyIconPaid: LazyComponent<typeof import("../components/icon/Paid.vue")['default']>
export const LazyIconShop: LazyComponent<typeof import("../components/icon/Shop.vue")['default']>
export const LazyIconStars: LazyComponent<typeof import("../components/icon/Stars.vue")['default']>
export const LazyIconStepArrow: LazyComponent<typeof import("../components/icon/StepArrow.vue")['default']>
export const LazyIconTruck: LazyComponent<typeof import("../components/icon/Truck.vue")['default']>
export const LazyIconTruckOutline: LazyComponent<typeof import("../components/icon/TruckOutline.vue")['default']>
export const LazyIconUserCheck: LazyComponent<typeof import("../components/icon/UserCheck.vue")['default']>
export const LazyIconVoucher: LazyComponent<typeof import("../components/icon/Voucher.vue")['default']>
export const LazyLayoutsFooter: LazyComponent<typeof import("../components/layouts/Footer.vue")['default']>
export const LazyLayoutsHeaderAuth: LazyComponent<typeof import("../components/layouts/HeaderAuth.vue")['default']>
export const LazyLayoutsHeaderProfile: LazyComponent<typeof import("../components/layouts/HeaderProfile.vue")['default']>
export const LazyLayoutsHeaderSeller: LazyComponent<typeof import("../components/layouts/HeaderSeller.vue")['default']>
export const LazyLayoutsHeaderWhite: LazyComponent<typeof import("../components/layouts/HeaderWhite.vue")['default']>
export const LazyLayoutsSearchBar: LazyComponent<typeof import("../components/layouts/SearchBar.vue")['default']>
export const LazyLayoutsSidebar: LazyComponent<typeof import("../components/layouts/sidebar/Index.vue")['default']>
export const LazyLayoutsSidebarItem: LazyComponent<typeof import("../components/layouts/sidebar/Item.vue")['default']>
export const LazyModalAddress: LazyComponent<typeof import("../components/modal/Address.vue")['default']>
export const LazyModalCourier: LazyComponent<typeof import("../components/modal/Courier.vue")['default']>
export const LazyModalReview: LazyComponent<typeof import("../components/modal/Review.vue")['default']>
export const LazyModalReviewItem: LazyComponent<typeof import("../components/modal/Review/Item.vue")['default']>
export const LazyModalVoucher: LazyComponent<typeof import("../components/modal/Voucher.vue")['default']>
export const LazyMyAccountFormGroup: LazyComponent<typeof import("../components/my-account/FormGroup.vue")['default']>
export const LazySellerCard: LazyComponent<typeof import("../components/seller/Card.vue")['default']>
export const LazySellerFormGroup: LazyComponent<typeof import("../components/seller/FormGroup.vue")['default']>
export const LazyUAccordion: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Accordion.vue")['default']>
export const LazyUAlert: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Alert.vue")['default']>
export const LazyUAvatar: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Avatar.vue")['default']>
export const LazyUAvatarGroup: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/AvatarGroup")['default']>
export const LazyUBadge: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Badge.vue")['default']>
export const LazyUButton: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Button.vue")['default']>
export const LazyUButtonGroup: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/ButtonGroup")['default']>
export const LazyUCarousel: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Carousel.vue")['default']>
export const LazyUChip: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Chip.vue")['default']>
export const LazyUDropdown: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Dropdown.vue")['default']>
export const LazyUIcon: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Icon.vue")['default']>
export const LazyUKbd: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Kbd.vue")['default']>
export const LazyULink: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Link.vue")['default']>
export const LazyUMeter: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Meter.vue")['default']>
export const LazyUMeterGroup: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/MeterGroup")['default']>
export const LazyUProgress: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/elements/Progress.vue")['default']>
export const LazyUCheckbox: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Checkbox.vue")['default']>
export const LazyUForm: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Form.vue")['default']>
export const LazyUFormGroup: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/FormGroup.vue")['default']>
export const LazyUInput: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Input.vue")['default']>
export const LazyUInputMenu: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/InputMenu.vue")['default']>
export const LazyURadio: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Radio.vue")['default']>
export const LazyURadioGroup: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/RadioGroup.vue")['default']>
export const LazyURange: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Range.vue")['default']>
export const LazyUSelect: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Select.vue")['default']>
export const LazyUSelectMenu: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/SelectMenu.vue")['default']>
export const LazyUTextarea: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Textarea.vue")['default']>
export const LazyUToggle: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/forms/Toggle.vue")['default']>
export const LazyUTable: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/data/Table.vue")['default']>
export const LazyUCard: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/layout/Card.vue")['default']>
export const LazyUContainer: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/layout/Container.vue")['default']>
export const LazyUDivider: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/layout/Divider.vue")['default']>
export const LazyUSkeleton: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/layout/Skeleton.vue")['default']>
export const LazyUBreadcrumb: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/Breadcrumb.vue")['default']>
export const LazyUCommandPalette: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/CommandPalette.vue")['default']>
export const LazyUCommandPaletteGroup: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/CommandPaletteGroup.vue")['default']>
export const LazyUHorizontalNavigation: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/HorizontalNavigation.vue")['default']>
export const LazyUPagination: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/Pagination.vue")['default']>
export const LazyUTabs: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/Tabs.vue")['default']>
export const LazyUVerticalNavigation: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/navigation/VerticalNavigation.vue")['default']>
export const LazyUContextMenu: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/ContextMenu.vue")['default']>
export const LazyUModal: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Modal.vue")['default']>
export const LazyUModals: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Modals.client.vue")['default']>
export const LazyUNotification: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Notification.vue")['default']>
export const LazyUNotifications: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Notifications.vue")['default']>
export const LazyUPopover: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Popover.vue")['default']>
export const LazyUSlideover: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Slideover.vue")['default']>
export const LazyUSlideovers: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Slideovers.client.vue")['default']>
export const LazyUTooltip: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/overlays/Tooltip.vue")['default']>
export const LazyNuxtWelcome: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']>
export const LazyNuxtLayout: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']>
export const LazyNuxtErrorBoundary: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']>
export const LazyClientOnly: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']>
export const LazyDevOnly: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']>
export const LazyServerPlaceholder: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const LazyNuxtLink: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']>
export const LazyNuxtLoadingIndicator: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']>
export const LazyNuxtTime: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']>
export const LazyNuxtRouteAnnouncer: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']>
export const LazyNuxtImg: LazyComponent<typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue")['default']>
export const LazyNuxtPicture: LazyComponent<typeof import("../node_modules/@nuxt/image/dist/runtime/components/NuxtPicture.vue")['default']>
export const LazyIcon: LazyComponent<typeof import("../node_modules/@nuxt/icon/dist/runtime/components/index")['default']>
export const LazyColorScheme: LazyComponent<typeof import("../node_modules/@nuxtjs/color-mode/dist/runtime/component.vue3.vue")['default']>
export const LazyNuxtPage: LazyComponent<typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']>
export const LazyNoScript: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']>
export const LazyLink: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']>
export const LazyBase: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']>
export const LazyTitle: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']>
export const LazyMeta: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']>
export const LazyStyle: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']>
export const LazyHead: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']>
export const LazyHtml: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']>
export const LazyBody: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']>
export const LazyNuxtIsland: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']>
export const LazyUModals: LazyComponent<IslandComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>>
export const LazyUSlideovers: LazyComponent<IslandComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>>
export const LazyNuxtRouteAnnouncer: LazyComponent<IslandComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>>

export const componentNames: string[]
